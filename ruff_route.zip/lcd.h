#ifndef LCD_H
#define LCD_H

#include <avr/io.h>

// LCD I2C address (8-bit address for the Crystalfontz panel)
#define LCD_ADDR 0x78

// Function declarations
void lcd_init(void);
void lcd_send_command(uint8_t cmd);
void lcd_write_string(uint8_t *str, uint8_t len);

#endif