// lcd.c
#include <avr/io.h>
#include <util/delay.h>
#include <stddef.h>
#include "i2c.h"

#define LCD_ADDR 0x78


void lcd_send_command(uint8_t cmd) {
    uint8_t buf[2] = { 0x80, cmd };
    i2c_io(LCD_ADDR, buf, 2, NULL, 0);
    _delay_us(120);
}

void lcd_init(void) {
    _delay_ms(500);
    lcd_send_command(0x38); // Function set (2-line)
    lcd_send_command(0x0F); // Display on, cursor on, blink on
    lcd_send_command(0x01); // Clear
    _delay_ms(15);
    lcd_send_command(0x06); // Entry mode: cursor → right
}

void lcd_write_string(uint8_t *str, uint8_t len) {
    // send control byte + all chars in one transaction
    uint8_t buf[1 + len];
    buf[0] = 0x40; // Co=0, A0=1 → data
    for (uint8_t i = 0; i < len; i++) {
        buf[1 + i] = str[i];
    }
    i2c_io(LCD_ADDR, buf, 1 + len, NULL, 0);
    _delay_us(120);
}
