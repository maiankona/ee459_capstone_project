#include <avr/io.h>
#include <util/delay.h>
#include <string.h>
#include <math.h>
#include "i2c.h"
#include "lcd.h"

// Pin Definitions
#define TRIG_PIN PD2  // Ultrasonic trigger
#define ECHO_PIN PD3  // Ultrasonic echo
#define MOTOR_A_PIN1 PD6
#define MOTOR_A_PIN2 PD7
#define MOTOR_A_PWM PB2
#define MOTOR_B_PIN1 PD4
#define MOTOR_B_PIN2 PD5
#define MOTOR_B_PWM PD3
#define LEFT_BUTTON PC1
#define SELECT_BUTTON PC2
#define RIGHT_BUTTON PC3
#define SPEAKER_PIN PB0
#define GPS_RX PD0
#define GPS_TX PD1

// Constants
#define STOP_DISTANCE 30  // cm
#define SLOW_SPEED 43
#define MEDIUM_SPEED 86
#define FAST_SPEED 128
#define CONGRATS_DURATION 30000  // 30 seconds
#define PULSE_TIMEOUT 60000  // timer counts
#define BEEP_FREQ 2000      // Hz
#define BEEP_DURATION 200   // ms
#define GPS_BAUD 9600
#define GPS_UPDATE_INTERVAL 1000  // ms
#define WAYPOINT_DISTANCE 15  // meters
#define M_PI 3.14159265358979323846

// States
typedef enum {
    STATE_INITIAL,
    STATE_ROUTE1,
    STATE_ROUTE2,
    STATE_SLOW,
    STATE_MEDIUM,
    STATE_FAST,
    STATE_LETSGO,
    STATE_CONGRATS
} state_t;

// GPS data structure
struct GPSData {
    float lat;
    float lon;
    uint8_t valid;
};

// Global variables
state_t current_state = STATE_INITIAL;
uint8_t selected_route = 0;  // 0: Route 1, 1: Route 2
uint8_t selected_speed = 1;  // 1: slow, 2: medium, 3: fast
float miles_walked = 0.0;
uint32_t last_time_check = 0;
uint32_t last_distance_update = 0;
float current_latitude = 0.0;
float current_longitude = 0.0;
uint8_t current_waypoint = 0;

// Route waypoints (example coordinates - replace with actual USC campus coordinates)
const float route1[] = {
    34.0224, -118.2851,  // Starting point
    34.0220, -118.2845,  // Waypoint 1
    34.0215, -118.2840,  // Waypoint 2
    34.0210, -118.2835   // End point
};

const float route2[] = {
    34.0224, -118.2851,  // Starting point
    34.0228, -118.2855,  // Waypoint 1
    34.0232, -118.2860,  // Waypoint 2
    34.0236, -118.2865   // End point
};

// Function to initialize UART for GPS
void init_uart(void) {
    uint16_t ubrr = ((F_CPU/(16UL*GPS_BAUD))-1);
    UBRR0H = ubrr >> 8;
    UBRR0L = ubrr;
    UCSR0B = (1 << RXEN0) | (1 << TXEN0);
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}

// Function to receive UART data
char usart_receive(void) {
    while (!(UCSR0A & (1 << RXC0)));
    return UDR0;
}

// Function to parse GGA sentence
uint8_t parse_gga(char *s, struct GPSData *g) {
    if (strncmp(s, "$GPGGA", 6)) return 0;
    
    char *tok = strtok(s, ",");
    uint8_t i = 0;
    
    while (tok) {
        switch (i) {
            case 2:  // Latitude
                g->lat = atof(tok) / 100.0;
                break;
            case 4:  // Longitude
                g->lon = atof(tok) / 100.0;
                break;
            case 6:  // Fix quality
                g->valid = (atoi(tok) > 0);
                break;
        }
        tok = strtok(NULL, ",");
        i++;
    }
    return 1;
}

// Function to calculate distance using Haversine formula
float calculate_distance(float lat1, float lon1, float lat2, float lon2) {
    float dLat = (lat2 - lat1) * M_PI / 180;
    float dLon = (lon2 - lon1) * M_PI / 180;
    float a = sin(dLat/2) * sin(dLat/2) +
              cos(lat1 * M_PI / 180) * cos(lat2 * M_PI / 180) *
              sin(dLon/2) * sin(dLon/2);
    return 6371000 * 2 * atan2(sqrt(a), sqrt(1-a));
}

// Function to update GPS data
void update_gps(void) {
    static char buf[100];
    static uint8_t bi = 0;
    struct GPSData gps = {0};
    
    if (UCSR0A & (1 << RXC0)) {
        char c = usart_receive();
        if (c == '$') bi = 0;
        if (bi < sizeof(buf) - 1) buf[bi++] = c;
        if (c == '\n') {
            buf[bi] = 0;
            if (parse_gga(buf, &gps) && gps.valid) {
                current_latitude = gps.lat;
                current_longitude = gps.lon;
                
                // Update distance if in walking state
                if (current_state == STATE_LETSGO) {
                    const float *route = (selected_route == 0) ? route1 : route2;
                    float dist = calculate_distance(current_latitude, current_longitude,
                                                 route[current_waypoint*2], 
                                                 route[current_waypoint*2+1]);
                    
                    // Convert meters to miles and add to total
                    miles_walked += dist / 1609.34;
                    
                    // Check if reached waypoint
                    if (dist < WAYPOINT_DISTANCE) {
                        current_waypoint++;
                        play_beep();
                    }
                }
            }
            bi = 0;
        }
    }
}

// Function to initialize ultrasonic sensor
void init_ultrasonic(void) {
    DDRD |= (1 << TRIG_PIN);
    DDRD &= ~(1 << ECHO_PIN);
}

// Function to initialize motors
void init_motors(void) {
    // Set direction pins as outputs
    DDRD |= (1 << MOTOR_A_PIN1) | (1 << MOTOR_A_PIN2) |
            (1 << MOTOR_B_PIN1) | (1 << MOTOR_B_PIN2);
    
    // Set PWM pins as outputs
    DDRB |= (1 << MOTOR_A_PWM);
    DDRD |= (1 << MOTOR_B_PWM);
    
    // Configure Timer1 for Motor A PWM
    TCCR1A = (1 << COM1B1) | (1 << WGM10);  // Fast PWM, 8-bit
    TCCR1B = (1 << WGM12) | (1 << CS11);    // Prescaler 8
    
    // Configure Timer2 for Motor B PWM
    TCCR2A = (1 << COM2B1) | (1 << WGM21) | (1 << WGM20);  // Fast PWM
    TCCR2B = (1 << CS21);                                   // Prescaler 8
}

// Function to initialize buttons
void init_buttons(void) {
    // Set button pins as inputs with pull-up
    DDRC &= ~((1 << LEFT_BUTTON) | (1 << SELECT_BUTTON) | (1 << RIGHT_BUTTON));
    PORTC |= (1 << LEFT_BUTTON) | (1 << SELECT_BUTTON) | (1 << RIGHT_BUTTON);
}

// Function to initialize speaker
void init_speaker(void) {
    DDRB |= (1 << SPEAKER_PIN);
}

// Function to play a beep
void play_beep(void) {
    TCCR0A = (1 << COM0A0);  // Toggle OC0A on compare match
    TCCR0B = (1 << WGM01);   // CTC mode
    OCR0A = (F_CPU / (2 * BEEP_FREQ)) - 1;
    TCCR0B |= (1 << CS01);   // Prescaler 8
    _delay_ms(BEEP_DURATION);
    TCCR0B &= ~(1 << CS01);
    PORTB &= ~(1 << SPEAKER_PIN);
}

// Function to get distance from ultrasonic sensor
uint16_t get_distance(void) {
    uint16_t pulse_width = 0;
    PORTD |= (1 << TRIG_PIN);
    _delay_us(10);
    PORTD &= ~(1 << TRIG_PIN);
    while (!(PIND & (1 << ECHO_PIN)));
    while (PIND & (1 << ECHO_PIN)) {
        pulse_width++;
        if (pulse_width > PULSE_TIMEOUT) return 0;
        _delay_us(1);
    }
    return pulse_width / 58;
}

// Function to set motor speed
void set_motor_speed(uint8_t speed) {
    OCR1B = speed;  // Motor A
    OCR2B = speed;  // Motor B
}

// Function to set motors forward
void set_motors_forward(void) {
    PORTD |= (1 << MOTOR_A_PIN1);
    PORTD &= ~(1 << MOTOR_A_PIN2);
    PORTD |= (1 << MOTOR_B_PIN1);
    PORTD &= ~(1 << MOTOR_B_PIN2);
}

// Function to stop motors
void stop_motors(void) {
    OCR1B = 0;  // Motor A
    OCR2B = 0;  // Motor B
}

// Function to update LCD display
void update_display(void) {
    char display_buffer[32];
    
    lcd_send_command(0x01);  // clear
    _delay_ms(15);
    lcd_send_command(0x80);  // set DDRAM addr = 0
    
    switch (current_state) {
        case STATE_INITIAL:
            lcd_write_string((uint8_t *)"WELCOME", 7);
            lcd_send_command(0xC0);
            lcd_write_string((uint8_t *)"Select your route", 16);
            lcd_send_command(0x94);
            lcd_write_string((uint8_t *)"WOOF", 4);
            break;
            
        case STATE_ROUTE1:
        case STATE_ROUTE2:
            lcd_write_string((uint8_t *)"Route 1", 7);
            lcd_send_command(0xC0);  // Second line
            lcd_write_string((uint8_t *)"Route 2", 7);
            break;
            
        case STATE_SLOW:
            lcd_write_string((uint8_t *)"Speed: **slow**", 14);
            lcd_send_command(0xC0);  // Second line
            lcd_write_string((uint8_t *)"medium  fast", 12);
            break;
            
        case STATE_MEDIUM:
            lcd_write_string((uint8_t *)"Speed: slow", 11);
            lcd_send_command(0xC0);  // Second line
            lcd_write_string((uint8_t *)"**medium**  fast", 15);
            break;
            
        case STATE_FAST:
            lcd_write_string((uint8_t *)"Speed: slow  medium", 18);
            lcd_send_command(0xC0);  // Second line
            lcd_write_string((uint8_t *)"**fast**", 8);
            break;
            
        case STATE_LETSGO:
            lcd_write_string((uint8_t *)"LETS GO!", 8);
            lcd_send_command(0xC0);
            sprintf(display_buffer, "Miles: %.2f", miles_walked);
            lcd_write_string((uint8_t *)display_buffer, strlen(display_buffer));
            lcd_send_command(0x94);
            sprintf(display_buffer, "Waypoint: %d", current_waypoint);
            lcd_write_string((uint8_t *)display_buffer, strlen(display_buffer));
            break;
            
        case STATE_CONGRATS:
            lcd_write_string((uint8_t *)"Route finished", 14);
            lcd_send_command(0xC0);  // Second line
            lcd_write_string((uint8_t *)"-- CONGRATS --", 14);
            break;
    }
}

// Function to check buttons
void check_buttons(void) {
    static uint8_t last_left = 1, last_select = 1, last_right = 1;
    
    uint8_t left = PINC & (1 << LEFT_BUTTON);
    uint8_t select = PINC & (1 << SELECT_BUTTON);
    uint8_t right = PINC & (1 << RIGHT_BUTTON);
    
    switch (current_state) {
        case STATE_INITIAL:
            if (!left || !select || !right) {
                current_state = STATE_ROUTE1;
            }
            break;
            
        case STATE_ROUTE1:
            if (!left || !right) {
                current_state = STATE_ROUTE2;
            } else if (!select) {
                current_state = STATE_SLOW;
            }
            break;
            
        case STATE_ROUTE2:
            if (!left || !right) {
                current_state = STATE_ROUTE1;
            } else if (!select) {
                current_state = STATE_SLOW;
            }
            break;
            
        case STATE_SLOW:
            if (!select) {
                current_state = STATE_LETSGO;
            } else if (!left) {
                current_state = STATE_FAST;
            } else if (!right) {
                current_state = STATE_MEDIUM;
            }
            break;
            
        case STATE_MEDIUM:
            if (!select) {
                current_state = STATE_LETSGO;
            } else if (!left) {
                current_state = STATE_SLOW;
            } else if (!right) {
                current_state = STATE_FAST;
            }
            break;
            
        case STATE_FAST:
            if (!select) {
                current_state = STATE_LETSGO;
            } else if (!left) {
                current_state = STATE_MEDIUM;
            } else if (!right) {
                current_state = STATE_SLOW;
            }
            break;
            
        default:
            break;
    }
    
    last_left = left;
    last_select = select;
    last_right = right;
}

int main(void) {
    // Initialize hardware
    init_ultrasonic();
    init_motors();
    init_buttons();
    init_speaker();
    init_uart();
    
    // Initialize LCD
    i2c_init(11);
    lcd_init();
    
    // Clear and home
    lcd_send_command(0x01);
    _delay_ms(15);
    lcd_send_command(0x80);
    
    // Initial state
    current_state = STATE_INITIAL;
    stop_motors();
    
    while (1) {
        // Update GPS every GPS_UPDATE_INTERVAL
        if (current_state == STATE_LETSGO) {
            update_gps();
        }
        
        // Check for obstacles
        uint16_t distance = get_distance();
        if (distance > 0 && distance < STOP_DISTANCE) {
            stop_motors();
            play_beep();
            _delay_ms(1000);
        }
        
        // Update display
        update_display();
        
        // Check buttons
        check_buttons();
        
        // Small delay
        _delay_ms(100);
    }
    
    return 0;
} 